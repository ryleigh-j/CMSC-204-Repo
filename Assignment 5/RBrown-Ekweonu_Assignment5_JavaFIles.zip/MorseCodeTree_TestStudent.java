package assignment5;
/*
* Class: CMSC 204 
* Instructor: Farnaz Eivazi
* Description: (Give a brief description for each Class) MorseCode to English converter
* Due: 4/18/24
* Platform/compiler: Eclipse
* I pledge that I have completed the programming  assignment independently. 
*  I have not copied the code from a student or any source. 
*  I have not given my code to any student.
*  Print your Name here: Ryleigh Brown-Ekweonu
*/

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class MorseCodeTree_TestStudent {
	MorseCodeTree tree,testTree;
	ArrayList<String>treeList;

	@BeforeEach
	void setUp() throws Exception {
		tree= new MorseCodeTree();
		testTree=new MorseCodeTree();
		treeList=new ArrayList<String>();
	}

	@AfterEach
	void tearDown() throws Exception {
		tree=testTree=null;
	}

	@Test
	void testGetRoot() {
		assertEquals(testTree.getRoot().data,"");
	}

	@Test
	void testSetRoot() {
		tree.setRoot(new TreeNode<String>("Hi"));
		assertEquals(tree.getRoot().data,"Hi");
	}

	@Test
	void testInsert() {
		tree.insert("..","i");
		assertEquals(tree.getRoot().left.left.data,"i");
		tree.insert(".---","j");
		assertEquals(tree.getRoot().left.right.right.right.data,"j");
		tree.insert("-.-.", "c");
		assertEquals(tree.getRoot().right.left.right.left.data,"c");


	}

	@Test
	void testAddNode() {
		
		tree.addNode(tree.getRoot(),".","e");
		tree.addNode(tree.getRoot(),".-","a");
		tree.addNode(tree.getRoot(),"-","t");
		tree.addNode(tree.getRoot(),"--","m");
		tree.addNode(tree.getRoot(),".-.","r");



		assertEquals(tree.getRoot().left.right.data,"a");
		assertEquals(tree.getRoot().left.data,"e");
		assertEquals(tree.getRoot().right.data,"t");
		assertEquals(tree.getRoot().right.right.data,"m");
		assertEquals(tree.getRoot().left.right.left.data,"r");


	}

	@Test
	void testFetch() {
		
		tree.addNode(tree.getRoot(),".","e");
		tree.addNode(tree.getRoot(),".-","a");
		assertEquals(tree.fetch(".-"),"a");
		assertEquals(tree.fetch("."),"e");
	}

	@Test
	void testFetchNode() {
		tree.addNode(tree.getRoot(),".","e");
		tree.addNode(tree.getRoot(),".-","a");

		assertEquals(tree.fetchNode(tree.getRoot(),".-"),"a");
		assertEquals(tree.fetchNode(tree.getRoot(),"."),"e");
	}

	@Test
	void testDelete() {
		try {
			
			tree.delete("h");
			testTree.delete("i");
			
		}catch(UnsupportedOperationException e) {
			System.out.println("correct exception thrown when testing MorseCodeTree.delete");
		}
	}

	@Test
	void testUpdate() {
		try {
					
			tree.delete("h");
			testTree.delete("i");
					
			}catch(UnsupportedOperationException e) {
					System.out.println("correct exception thrown when testing MorseCodeTree.update");
			}
	}

	@Test
	void testBuildTree() {
		assertEquals(testTree.fetch("--"),"m");
		assertEquals(testTree.fetch("."),"e");
		assertEquals(testTree.fetch("-"),"t");
		assertEquals(testTree.fetch("--.-"),"q");



	}

	@Test
	void testToArrayList() {
		treeList=testTree.toArrayList();
		assertEquals("h",treeList.get(0));
		assertEquals("s",treeList.get(1));
		assertEquals("v",treeList.get(2));
	}

	@Test
	void testLNRoutputTraversal() {
		testTree.LNRoutputTraversal(testTree.getRoot(), treeList);
		assertEquals("h",treeList.get(0));
		assertEquals("s",treeList.get(1));
		assertEquals("v",treeList.get(2));


	}

}
