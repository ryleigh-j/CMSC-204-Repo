package assignment5;
/*
* Class: CMSC 204 
* Instructor: Farnaz Eivazi
* Description: (Give a brief description for each Class) MorseCode to English converter
* Due: 4/18/24
* Platform/compiler: Eclipse
* I pledge that I have completed the programming  assignment independently. 
*  I have not copied the code from a student or any source. 
*  I have not given my code to any student.
*  Print your Name here: Ryleigh Brown-Ekweonu
*/

import java.util.ArrayList;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;


public class MorseCodeConverter {
	private static MorseCodeTree  morseCode =new MorseCodeTree();

	
	public MorseCodeConverter() {
		
	}
	
	public static String printTree() {
		ArrayList<String>codeTree=morseCode.toArrayList();
		String codeString="";
		for(String s: codeTree) {
			if(s.equals("o")) {
				codeString+=s;
			}else {
				codeString+=s +" ";
			}
			
		}
		return codeString;
	}
	
	public static String convertToEnglish(String code) {
		String english="";
		String[]sentence=code.split("/");
		for(int i=0;i<sentence.length;i++) {
			String[]words=sentence[i].split(" ");
			for(int j=0;j<words.length;j++) {
				english+=morseCode.fetch(words[j]);
			}
			if(i != sentence.length-1) {
				english+=" ";

			}
		}
		
		return english;
	}
	
	public static String convertToEnglish(File codeFile) throws FileNotFoundException{
		String english="";
		if(codeFile.exists()) {
			Scanner input= new Scanner(codeFile);
			if(input.hasNext()) {
				english=convertToEnglish(input.nextLine());
			}
			input.close();
		}else {
			throw new FileNotFoundException();
		}
		return english;
	}

}
