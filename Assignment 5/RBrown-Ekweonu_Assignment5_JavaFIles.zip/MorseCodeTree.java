package assignment5;
/*
* Class: CMSC 204 
* Instructor: Farnaz Eivazi
* Description: (Give a brief description for each Class) MorseCode to English converter
* Due: 4/18/24
* Platform/compiler: Eclipse
* I pledge that I have completed the programming  assignment independently. 
*  I have not copied the code from a student or any source. 
*  I have not given my code to any student.
*  Print your Name here: Ryleigh Brown-Ekweonu
*/

import java.util.ArrayList;

public class MorseCodeTree implements LinkedConverterTreeInterface<String> {

	
	TreeNode<String>treeRoot;
	public MorseCodeTree() {
		buildTree();
	}
	
	public TreeNode<String>getRoot(){
		return this.treeRoot;
	}

	@Override
	public void setRoot(TreeNode<String> newNode) {
		// TODO Auto-generated method stub
		this.treeRoot=newNode;
		
	}

	@Override
	public void insert(String code, String result) {
		// TODO Auto-generated method stub
		addNode(treeRoot,code,result);
	}

	@Override
	public void addNode(TreeNode<String> root, String code, String letter) {
		// TODO Auto-generated method stub
		TreeNode<String>newNode; 

		if(code.length()==1) {
			newNode=new TreeNode<String>(letter);
			if(code.charAt(0)=='.') {
				root.left=newNode;
			}else if(code.charAt(0)=='-') {
				root.right=newNode;
			}
		}else if(code.length()>1) {
			newNode=new TreeNode<String>("");
			if(code.charAt(0)=='.') {
				addNode(root.left,code.substring(1),letter);
			}else if(code.charAt(0)=='-') {
				addNode(root.right,code.substring(1),letter);
			}
			
		}
		
	}

	@Override
	public String fetch(String code) {
		// TODO Auto-generated method stub
		return fetchNode(treeRoot,code);
	}

	@Override
	public String fetchNode(TreeNode<String> root, String code) {
		// TODO Auto-generated method stub
		if(code.length()==1) {
			
			if(code.charAt(0)=='.') {
				return root.left.data;
			}else if(code.charAt(0)=='-') {
				return root.right.data;
			}
		}else if(code.length()>1) {
			if(code.charAt(0)=='.') {
				return fetchNode(root.left,code.substring(1));
			}else if(code.charAt(0)=='-') {
				return fetchNode(root.right,code.substring(1));
			}
			
		}
		return "";
	}

	@Override
	public MorseCodeTree delete(String data) throws UnsupportedOperationException {
		// TODO Auto-generated method stub
		throw new UnsupportedOperationException();
	}

	@Override
	public MorseCodeTree update() throws UnsupportedOperationException {
		// TODO Auto-generated method stub
		throw new UnsupportedOperationException();
	}

	@Override
	public void buildTree() {
		// TODO Auto-generated method stub
		String[] letter= {"e","t","i","a","n","m","s","u","r","w","d",
							"k","g","o","h","v","f","l","p","j","b","x",
							"c","y","z","q"};
		String[]code= {".","-","..",".-","-.","--","...","..-",".-.",".--",
				     "-..","-.-","--.","---","....","...-","..-.",".-..",
				     ".--.",".---","-...","-..-","-.-.","-.--","--..","--.-"};
		treeRoot=new TreeNode<String>("");
		for(int i=0;i<code.length;i++) {
			insert(code[i],letter[i]);
		}
		
	}

	@Override
	public ArrayList<String> toArrayList() {
		// TODO Auto-generated method stub
		ArrayList<String>treeList=new ArrayList<String>();
		LNRoutputTraversal(treeRoot,treeList);
		return treeList;
	}

	@Override
	public void LNRoutputTraversal(TreeNode<String> root, ArrayList<String> list) {
		// TODO Auto-generated method stub
		if(root==null) {
			return;
		}
		LNRoutputTraversal(root.left,list);
		list.add(root.data);
		LNRoutputTraversal(root.right,list);
		
		
	}
}
