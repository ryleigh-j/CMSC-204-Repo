package assignment5;
/*
* Class: CMSC 204 
* Instructor: Farnaz Eivazi
* Description: (Give a brief description for each Class) MorseCode to English converter
* Due: 4/18/24
* Platform/compiler: Eclipse
* I pledge that I have completed the programming  assignment independently. 
*  I have not copied the code from a student or any source. 
*  I have not given my code to any student.
*  Print your Name here: Ryleigh Brown-Ekweonu
*/

public class TreeNode<T> {
	protected T data;
	protected TreeNode<T>left;
	protected TreeNode<T>right;
	
	public TreeNode(T dataNode) {
		this.data=dataNode;
		this.left=null;
		this.right=null;
	}
	public TreeNode(TreeNode<T>node ) {
		TreeNode<T>copy= node;
		this.data=copy.data;
		this.left=copy.left;
		this.right=copy.right;
	}
	
	public T getData() {
		return this.data;
	}

}
