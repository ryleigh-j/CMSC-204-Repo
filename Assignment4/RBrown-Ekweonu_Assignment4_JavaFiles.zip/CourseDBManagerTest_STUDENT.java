package assignment4;

import static org.junit.Assert.assertTrue;

/*
* Class: CMSC 204 
* Instructor: Farnaz Eivazi
* Description: (Give a brief description for each Class) Database for courses by reading from file or by inputing them
* Due: 4/1/24
* Platform/compiler: Eclipse
* I pledge that I have completed the programming  assignment independently. 
*  I have not copied the code from a student or any source. 
*  I have not given my code to any student.
*  Print your Name here: Ryleigh Brown-Ekweonu
*/

import static org.junit.jupiter.api.Assertions.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


/**
 * Test template provided to students
 * Students must implement the methods
 * 
 * @author Farnaz Eivazi
 * @version 1/31/2024
 *
 */
class CourseDBManagerTest_STUDENT {
	private CourseDBManager courseManager;
	private CourseDBElement course,c1,c2;
	private ArrayList<String>courses;
	

	@BeforeEach
	void setUp() throws Exception {
		courseManager= new CourseDBManager();
		c1=new CourseDBElement("CSMC 204",25961,4,"SC 404","John Bob");
		c2= new CourseDBElement("CSMC 140",85416,3,"SW 223","Anne Crackle");
		courseManager.add(c1.getID(),c1.getCRN(),c1.getCredits(),c1.getRoomNum(),c1.getInstructor());
		courseManager.add(c1.getID(),c1.getCRN(),c1.getCredits(),c1.getRoomNum(),c1.getInstructor());
		courseManager.add(c2.getID(),c2.getCRN(),c2.getCredits(),c2.getRoomNum(),c2.getInstructor());

		
		
	}

	@AfterEach
	void tearDown() throws Exception {
		courseManager=null;
		course=c1=c2=null;
	}

	@Test
	void testAdd() {
		course=new CourseDBElement("HIST 204", 65654, 4, "HU 405", "Nancy Drew");
		courseManager.add( course.getID(),course.getCRN(),course.getCredits(),course.getRoomNum(),course.getInstructor());
	
		try {
			assertTrue(course.equals(courseManager.database.get(course.getCRN())));
			courseManager.database.get(84529);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("Correct Exception thrown when testing CourseDBManager.add");
		}
	}

	@Test
	void testShowAll() {
		courses=courseManager.showAll();
		assertEquals(c2.toString(),courses.get(0));
		assertEquals(c1.toString(),courses.get(1));
		assertEquals(c1.toString(),courses.get(2));


		
	}

	@Test
	void testReadFile() {
		try {
			File course= new File("course.txt");
			
			courseManager.readFile(course);
			courses=courseManager.showAll();
			Scanner input= new Scanner(course);
			while(input.hasNextLine()) {
				String line= input.nextLine();
				for(String s:courses) {
					if(s.equals(line)) {
						assertTrue(s.equals(line));
					}
				}
			}
			
			
			
			
		}catch(FileNotFoundException e) {
			System.out.println("Correct exception thrown when testing CourseDBManager.ReadFile");
		}
		
	}

	@Test
	void testGet() {
		
		
			assertTrue(c1.equals(courseManager.get(c1.getCRN())));
			courseManager.get(34578);
			assertTrue(c2.equals(courseManager.get(c2.getCRN())));

	}

}
