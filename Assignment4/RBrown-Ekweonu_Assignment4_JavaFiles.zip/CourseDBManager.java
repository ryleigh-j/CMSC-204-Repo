package assignment4;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class CourseDBManager implements CourseDBManagerInterface {
	protected CourseDBStructure database;
	protected CourseDBElement course;
	protected final int MAX_ELEMENTS=500;
	
	public CourseDBManager() {
		database=new CourseDBStructure(MAX_ELEMENTS);
		
	}
	@Override
	public void add(String id, int crn, int credits, String roomNum, String instructor) {
		// TODO Auto-generated method stub
		course= new CourseDBElement(id,crn,credits,roomNum,instructor);
		database.add(course);
	}

	@Override
	public CourseDBElement get(int crn) {
		// TODO Auto-generated method stub
		try {
			course=database.get(crn);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("Element can not be found-CourseDBManager.get");
		}
		return course;
	}

	@Override
	public void readFile(File input) throws FileNotFoundException {
		// TODO Auto-generated method stub
		if(input.exists()) {
			Scanner read=new Scanner(input);
		    String c[]=new String[7];
		    while(read.hasNextLine()){
		      Scanner line= new Scanner(read.nextLine());
		      line.useDelimiter(" ");
		      for(int i=0;i<c.length;i++){
		        c[i]=" ";
		        if(line.hasNext()){
		          c[i]=line.next();
		        }
		      }

				add(c[0],Integer.valueOf(c[1]),Integer.valueOf(c[2]),c[3],c[4]+" "+c[5]+" "+c[6]);

		    }
		}else {
			throw new FileNotFoundException();
		}
		
		
		
		
	}

	@Override
	public ArrayList<String> showAll() {
		// TODO Auto-generated method stub
		ArrayList<String>all= database.showAll();
		return all;
	}

}
