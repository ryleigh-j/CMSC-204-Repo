package assignment4;
/*
* Class: CMSC 204 
* Instructor: Farnaz Eivazi
* Description: (Give a brief description for each Class) Database for courses by reading from file or by inputing them
* Due: 4/1/24
* Platform/compiler: Eclipse
* I pledge that I have completed the programming  assignment independently. 
*  I have not copied the code from a student or any source. 
*  I have not given my code to any student.
*  Print your Name here: Ryleigh Brown-Ekweonu
*/

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.ArrayList;
/**
 * Test template provided to students
 * Students must implement the methods
 * 
 * @author Farnaz Eivazi
 * @version 1/31/2024
 *
 */
class CourseDBStructureTest_STUDENT {
	private CourseDBStructure database;
	private CourseDBElement c1,c2,c3,c4,c5;
	private ArrayList<String> courses;

	@BeforeEach
	void setUp() throws Exception {
		database= new CourseDBStructure(6);
		c1=new CourseDBElement("CSMC 204",25961,4,"SC 404","John Bob");
		c2= new CourseDBElement("CSMC 140",85416,3,"SW 223","Anne Crackle");
		c3= new CourseDBElement("MATH 284",69854,4,"SA 105","Sally Mae");
		c4= new CourseDBElement("ENGL 102",45896,3,"HU 220","Mark Eugle");
		c5= c1;		
		database.add(c1);
		database.add(c2);
		database.add(c5);
	}

	@AfterEach
	void tearDown() throws Exception {
		database=null;
		c1=c2=c3=c4=c5=null;
	}

	@Test
	void testCourseDBStructureStringInt() {
		database= new CourseDBStructure("Testing",55);
		assertEquals(55,database.getTableSize());
	}

	@Test
	void testCourseDBStructureInt() {
		database=new CourseDBStructure(55);
		assertEquals(43,database.getTableSize());
	}
	

	@Test
	void testAdd() {
		database.add(c1);
		database.add(c2);
		database.add(c5);
		try {
			assertTrue(c1.equals(database.get(c1.getCRN())));
			assertTrue(c2.equals(database.get(c2.getCRN())));
			assertTrue(c5.equals(database.get(c5.getCRN())));


		}catch(IOException e ) {
			System.out.println("Correct exception thrown when testing CourseDBStructure.get");
		}


	}

	@Test
	void testShowAll() {
		courses=database.showAll();
		assertEquals(c2.toString(),courses.get(0));
		assertEquals(c1.toString(),courses.get(1));
		assertEquals(c5.toString(),courses.get(2));


		
	}

	@Test
	void testGet() {
		try {
			assertTrue(c1.equals(database.get(c1.getCRN())));
			database.get(c3.getCRN());
			
		}catch(IOException e ) {
			System.out.println("Correct exception thrown when testing CourseDBStructure.get");
		}
	}

	@Test
	void testGetTableSize() {
		assertEquals(7,database.getTableSize());
	}

	@Test
	void testGet4KPrime() {
		assertEquals(7,CourseDBStructure.get4KPrime(6));
		assertEquals(347,CourseDBStructure.get4KPrime(333));
		assertEquals(151,CourseDBStructure.get4KPrime(150));
		assertEquals(443,CourseDBStructure.get4KPrime(443));


	}

}
