package assignment4;
/*
* Class: CMSC 204 
* Instructor: Farnaz Eivazi
* Description: (Give a brief description for each Class) Database for courses by reading from file or by inputing them
* Due: 4/1/24
* Platform/compiler: Eclipse
* I pledge that I have completed the programming  assignment independently. 
*  I have not copied the code from a student or any source. 
*  I have not given my code to any student.
*  Print your Name here: Ryleigh Brown-Ekweonu
*/

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.ListIterator;

public class CourseDBStructure implements CourseDBStructureInterface {
	private  LinkedList<CourseDBElement>[] table;
	private int size;
	private String test;
	
	@SuppressWarnings("unchecked")
	public CourseDBStructure(String numElements,int size) {
		this.test= numElements;
		this.size=size;
		this.table=(LinkedList<CourseDBElement>[]) new LinkedList [this.size];
		
	}
	
	@SuppressWarnings("unchecked")
	public CourseDBStructure(int num) {
		 
		this.size=get4KPrime((int)(num/1.5));
		this.table=  (LinkedList<CourseDBElement>[]) new LinkedList [this.size];
		
	}

	@Override
	public void add(CourseDBElement element) {
		// TODO Auto-generated method stub
		int index= element.getCRN()% this.size;
		LinkedList<CourseDBElement>list= new LinkedList<CourseDBElement>();
		if(table[index]==null) {
			table[index]=list;
			
			
		}
		
		table[index].add(element);
		
	}

	@Override
	public CourseDBElement get(int crn) throws IOException {
		// TODO Auto-generated method stub
		int index=crn%this.size;
		if(this.table[index]==null) {
			throw new IOException();
		}
		LinkedList<CourseDBElement>list= this.table[index];
		
		
		return list.getFirst();
	}

	@Override
	public ArrayList<String> showAll() {
		// TODO Auto-generated method stub
		ArrayList<String>all=new ArrayList<String>();
		for(int i=0;i<this.table.length;i++) {
			if(table[i]!=null) {
				for(CourseDBElement course: table[i]) {
					all.add(course.toString());
				}
			}
		}
		return all;
	}

	@Override
	public int getTableSize() {
		// TODO Auto-generated method stub
		return table.length;
	}
	
	public static int get4KPrime(int num) {
		boolean prime=true;
		if(num%2==0 || num<0) {
			prime=false;
		}
		for(int i=3;i<Math.sqrt(num);i++) {
			if(num%i==0) {
				prime=false;
			}
		}
		if(prime==false) {
			int primeNum=0;
			if(num<3) {
				return 3;
			}
			int x=(num-3)/4;
			int y=0;
			boolean foundPrime=false;
			
			while(foundPrime==false) {
				x+=1;
				y=4*x+3;
				prime=true;
				if(y%2==0){
					prime=false;
				}
				for(int i=3;i<Math.sqrt(y);i++) {
					if(y%i==0) {
						prime=false;
					}
				}
				if(prime) {
					foundPrime=true;
					
				}else {
					foundPrime=false;
				}
				
			}
			primeNum=y;
			return primeNum;

			
		}
		return num;
		
	}

	
}
