package assignment4;
/*
* Class: CMSC 204 
* Instructor: Farnaz Eivazi
* Description: (Give a brief description for each Class) Database for courses by reading from file or by inputing them
* Due: 4/1/24
* Platform/compiler: Eclipse
* I pledge that I have completed the programming  assignment independently. 
*  I have not copied the code from a student or any source. 
*  I have not given my code to any student.
*  Print your Name here: Ryleigh Brown-Ekweonu
*/




public class CourseDBElement implements Comparable<CourseDBElement> {
	private String courseID;
	private int crn;
	private int credits;
	private String roomNum;
	private String instructor;
	
	public CourseDBElement() {
		this(" ",0,0," "," ");
		
	}
	
	public CourseDBElement(String id,int crn,int credits,String roomNum,String instructor) {
		this.courseID=id;
		this.crn=crn;
		this.credits=credits;
		this.roomNum=roomNum;
		this.instructor=instructor;
	}
	public CourseDBElement(CourseDBElement element) {
		this(element.courseID,element.crn,element.credits,element.roomNum,element.instructor);
	}
	
	public void setID(String id) {
		this.courseID=id;
	}
	
	public String getID() {
		return this.courseID;
	}
	public void setCRN(int crn) {
		this.crn=crn;
	}
	public int getCRN() {
		return this.crn;
	}
	public void setCredits(int credits) {
		this.credits=credits;
	}
	public int getCredits() {
		return this.credits;
	}
	public void setInstructor(String instructor) {
		this.instructor=instructor;
	}
	public String getInstructor() {
		return this.instructor;
	}
	public void setRoomNum(String roomNum) {
		this.roomNum=roomNum;
	}
	public String getRoomNum() {
		return this.roomNum;
	}
	public int hashCode() {
		return this.crn;
	}
	public boolean equals(CourseDBElement other) {
		return other.courseID.equals(this.courseID) &&
				other.crn==this.crn &&
				other.credits==this.credits &&
				other.roomNum.equals(this.roomNum)&&
				other.instructor.equals(this.instructor);
	}
	public String toString() {
		return "Course:" +this.courseID+
				" CRN:"+ this.crn+
				" Credits:"+ this.credits+
				" Instructor:"+ this.instructor+
				" Room:"+ this.roomNum+"\n";
		
	}

	@Override
	public int compareTo(CourseDBElement o) {
		// TODO Auto-generated method stub
		return 0;
	}












}
