package generic_Lab;

public class DataSetGen<T extends Measurable> {
	private double sum;
	private T maximum;
	private int count;
	
	
	//constructor 
	
	public DataSetGen() {
		sum=0;
		count=0;
		maximum=null;
	}
	
	//adds data to set
	
	public void add(T x) {
		sum=sum+ x.getMeasure();
		if(count==0 || maximum.getMeasure()< x.getMeasure()) {
			maximum=x;
		}
		count++;
	}
	//gets average
	
	public double getAverage() {
		if(count==0) {
			return 0;
		}else {
			return sum/count;
		}
	}
	//gets the largest of data
	public T getMaximum() {
		return maximum;
	}
	

}
