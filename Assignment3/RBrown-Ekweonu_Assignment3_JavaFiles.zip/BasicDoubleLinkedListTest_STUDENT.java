package assignment3;


/**
 * You must implement the following test case methods
 */
import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.NoSuchElementException;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class BasicDoubleLinkedListTest_STUDENT {
	private BasicDoubleLinkedList<String>stringList;
	private String[] names;
	private Comparator<String>comparator;
	private BasicDoubleLinkedList<String>.DoubleLinkedListIterator iterator;
	private ArrayList<String>nameList;
	

	@BeforeEach
	void setUp() throws Exception {
		stringList= new BasicDoubleLinkedList<String>();
		names= new String[]{"Jill","Jack","Tim","Leo","Mark","Mary","John","Jane","Huey"};
		comparator= new Comparator<String>() {
			
			public int compare(String s1,String s2) {
				return s1.compareTo(s2);
			}
		};
		
	}
	

	@AfterEach
	void tearDown() throws Exception {
		stringList=null;
		names=null;
		comparator=null;
	}

	@Test
	void testGetSize() {
		
		assertEquals(0,stringList.getSize());
		stringList.addToEnd(names[0]);
		assertEquals(1,stringList.getSize());
		stringList.addToFront(names[1]);
		assertEquals(2,stringList.getSize());

		
	}

	@Test
	void testAddToEnd() {
		stringList.addToEnd(names[0]);
		assertEquals(names[0],stringList.getFirst());
		assertEquals(names[0],stringList.getLast());
		
	}

	@Test
	void testAddToFront() {
		stringList.addToEnd(names[0]);
		stringList.addToFront(names[1]);
		assertEquals(names[1],stringList.getFirst());
		assertEquals(names[0],stringList.getLast());
		stringList.addToFront(names[2]);
		assertEquals(names[2],stringList.getFirst());

	}

	@Test
	void testGetFirst() {
		assertNull(stringList.getFirst());
	}

	@Test
	void testGetLast() {
		assertNull(stringList.getLast());
	}

	@Test
	void testIterator() {
		
		stringList.addToEnd(names[0]);
		stringList.addToFront(names[1]);
		stringList.addToFront(names[2]);
		iterator=stringList.new DoubleLinkedListIterator();

		try {
			assertEquals(names[1],iterator.next());
			assertEquals(names[0],iterator.next());
			iterator.next();
		}catch (NoSuchElementException e) {
			System.out.println("Correct exception thrown"
					+ " when testing iterator.next- "
					+ "NoSuchElementException");
		}
		
		try {
			assertTrue(iterator.hasNext());
			assertTrue(iterator.hasNext());
			iterator.hasNext();
		}catch (NoSuchElementException e) {
			System.out.println("Correct exception thrown"
					+ " when testing iterator.hasNext- "
					+ "NoSuchElementException");
		}
		
		try {
			assertEquals(names[1],iterator.previous());
			assertEquals(names[2],iterator.previous());
			iterator.previous();

			


		}catch (NoSuchElementException e) {
			System.out.println("Correct exception thrown"
					+ " when testing iterator.previous- "
					+ "NoSuchElementException");
		}
		try {
			
			iterator.hasPrevious();
			
			assertEquals(names[1],iterator.next());
			assertEquals(names[2],iterator.next());
			assertEquals(names[1],iterator.previous());
			assertEquals(names[2],iterator.previous());



			


		}catch (NoSuchElementException e) {
			System.out.println("Correct exception thrown"
					+ " when testing iterator.hasPrevious- "
					+ "NoSuchElementException");
		}
		
	}

	@Test
	void testRemove() {
		stringList.addToEnd(names[0]);
		stringList.addToFront(names[1]);
		assertEquals(stringList.getFirst(),stringList.remove("Jack", comparator).data);

		stringList.addToFront(names[2]);
		stringList.addToEnd(names[3]);
		stringList.addToEnd(names[4]);




		
		assertEquals("Leo",stringList.remove("Leo", comparator).data);
	}

	@Test
	void testRetrieveFirstElement() {
		stringList.addToEnd(names[0]);
		stringList.addToFront(names[1]);
		stringList.addToFront(names[2]);
		assertEquals(names[2],stringList.retrieveFirstElement());
		assertEquals(2,stringList.getSize());
		assertEquals(names[1],stringList.retrieveFirstElement());
		assertEquals(1,stringList.getSize());
		assertEquals(names[0],stringList.retrieveFirstElement());
		assertEquals(0,stringList.getSize());
		assertNull(stringList.retrieveFirstElement());


		
	}

	@Test
	void testRetrieveLastElement() {
		stringList.addToEnd(names[0]);
		stringList.addToFront(names[1]);
		stringList.addToFront(names[2]);
		assertEquals(names[0],stringList.retrieveLastElement());
		assertEquals(2,stringList.size);
		assertEquals(names[1],stringList.getLast());
		assertEquals(names[1],stringList.retrieveLastElement());
		assertEquals(1,stringList.getSize());
		assertEquals(names[2],stringList.retrieveLastElement());
		assertEquals(0,stringList.getSize());
		assertNull(stringList.retrieveLastElement());
		
	}

	@Test
	void testToArrayList() {
		stringList.addToEnd(names[2]);
		stringList.addToFront(names[1]);
		stringList.addToFront(names[0]);
		stringList.addToEnd(names[3]);
		stringList.addToEnd(names[4]);
		nameList=stringList.toArrayList();
		
		  for(int i=0;i<stringList.size;i++) { 
			  assertEquals(names[i],nameList.get(i));
		  }
		 
		
	}
	
	


}
