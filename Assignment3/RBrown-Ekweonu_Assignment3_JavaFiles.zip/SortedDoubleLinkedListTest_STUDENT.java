package assignment3;



/**
 * You must implement the following test case methods
 */
import static org.junit.jupiter.api.Assertions.*;

import java.util.Comparator;
import java.util.NoSuchElementException;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import assignment3.BasicDoubleLinkedList.DoubleLinkedListIterator;

class SortedDoubleLinkedListTest_STUDENT {

	private SortedDoubleLinkedList<String> list;
	private String[] names;
	private Comparator<String>comparator;
	private BasicDoubleLinkedList<String>.DoubleLinkedListIterator iterator;

	@BeforeEach
	void setUp() throws Exception {
		names= new String[]{"Jill","Jack","Tim","Leo","Mark","Mary","John","Jane","Huey"};
		comparator= new Comparator<String>() {
			
			public int compare(String s1,String s2) {
				return s1.compareTo(s2);
			}
		};
		list= new SortedDoubleLinkedList<String>(comparator);
	}

	@AfterEach
	void tearDown() throws Exception {
		names=null;
		list=null;
		comparator=null;
		iterator=null;
	}
	@Test
	void testIterator() {
		list.add(names[0]);
		list.add(names[1]);
		list.add(names[2]);
		iterator=list.new DoubleLinkedListIterator();
		try {
			assertTrue(iterator.hasNext());
			
		}catch(NoSuchElementException e) {
			
		}
	}

	@Test
	void testRemove() {
		list.add(names[1]);
		list.add(names[0]);
		list.add(names[2]);
		assertEquals(names[0],list.remove(names[0],comparator));


	}

	@Test
	void testAdd() {
		list.add(names[0]);
		list.add(names[1]);
		assertEquals(names[1],list.head.data);
		list.add(names[2]);
	}

}
