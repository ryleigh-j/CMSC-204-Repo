package assignment3;

import java.util.Comparator;
import java.util.ListIterator;

public class SortedDoubleLinkedList<T> extends BasicDoubleLinkedList<T> {
	private Comparator<T> comparator;
	protected Node head,tail;

	public SortedDoubleLinkedList(Comparator<T >compareableObject) {
		super();
		head=super.head;
		tail=super.tail;

		this.comparator=compareableObject;
	}
	public void add(T data) {
		
		Node newNode= new Node(data);
		Node current=this.head;
		
		if(this.head==null) {
			this.head=newNode;
			this.tail=newNode;
		}else {
			int compare=comparator.compare(data, current.data);
			if(compare<0) {
				newNode.next=current;
				current.prev=newNode;
				this.head=newNode;
			}
			
			while(compare>=0 &&current!=null) {
				current=current.next;
				compare=comparator.compare(data, current.data);
				
				
			}
		
			
			newNode.next=current;
			newNode.prev=current.prev;
			current.prev.next=newNode;
			current.prev=newNode;
		}
		
		
		
		
		
		
		
		
	}
	
	public void addToEnd(T data) throws UnsupportedOperationException{
		throw new UnsupportedOperationException();
	}
	
	public void addToFront(T data) throws UnsupportedOperationException{
		throw new UnsupportedOperationException();
	}
	
	public ListIterator<T> iterator(){
		return super.iterator();
		
	}
	public BasicDoubleLinkedList<T>.Node remove(T data, Comparator<T> comparator){
		return super.remove(data, comparator);
	}

}
