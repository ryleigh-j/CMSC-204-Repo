package assignment3;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.ListIterator;
import java.util.NoSuchElementException;
public class BasicDoubleLinkedList<T>implements Iterable<T>{
	protected Node head;
	protected Node tail;
	protected int size;
	
	public  BasicDoubleLinkedList() {
		this.head=null;
		this.tail=null;
		this.size=0;
	}
	
	public int getSize() {
		return this.size;
	}
	
	public void addToEnd(T data) {
		Node nextNode=new Node(data);

		if(this.tail==null) {
			this.tail=nextNode;
			this.head=nextNode;
			
		}else {
			this.tail.next= nextNode;
			nextNode.prev=this.tail;
			this.tail= nextNode;
			this.tail.next=null;
		}
		this.size++;
		
	}
	public void addToFront(T data) {
		Node frontNode=new Node(data);
		if(this.head==null) {
			this.head=frontNode;
			this.tail=frontNode;
		}else {
			this.head.prev=frontNode;
			frontNode.next=this.head;
			this.head=frontNode;
			this.head.prev=null;
		}
		this.size++;
	}
	public T getFirst() {
		if(this.head==null) {
			return null;
		}else {
			return new Node(this.head.data).data;
		}
		
	}
	
	public T getLast() {
		if(this.head==null) {
			return null;
		}else {
			return new Node(this.tail.data).data;

		}
	}
	
	public ListIterator<T>iterator(){
		return new DoubleLinkedListIterator();
	}
	
	public BasicDoubleLinkedList<T>.Node remove(T targetData,Comparator<T>comparator){
		Node currentNode= this.head;
		Node removed=null;
		while(currentNode !=null) {
			if(comparator.compare(currentNode.data, targetData)==0){
				removed=currentNode;
				currentNode=null;
			}else {
				currentNode= currentNode.next;
			}
		}
		return removed;
		
		
	}
	public T retrieveFirstElement() {
		T first=null;
		if(size==0) {
			return null;
		}else if(size==1) {
			first=this.head.data;
			this.head=null;
			this.tail=null;
			
			
		}else if(size>1) {

			first=this.head.data;
			this.head=this.head.next;
			
			if(this.head.next==null) {
				this.tail=this.head;
			}
		}
		this.size--;
		return first;
		
	}
	public T retrieveLastElement() {
		T last=null;
		if(size==0) {
			return null;
		}else if(size==1) {
			last=this.tail.data;
			this.head=null;
			this.tail=null;
		}else if(size>1) {
			last= this.tail.data;
			this.tail=this.tail.prev;
			
			if(this.tail.prev==null) {
				this.head=this.tail;
			}
		}
		this.size--;
		return last;
		
	}
	public ArrayList<T>toArrayList(){
		ArrayList<T> list=new ArrayList<T>();
		BasicDoubleLinkedList<T>.DoubleLinkedListIterator iterator= (BasicDoubleLinkedList<T>.DoubleLinkedListIterator) iterator();
		if(this.head!=null) {
			list.add(head.data);

		}
		try {
			
			while(iterator.hasNext()==true) {
				T current=iterator.currentNode.data;
				T next= iterator.next();
				list.add(current);
				
				list.add(next);			}
		}catch(NoSuchElementException e) {
			
		}
		
		
		return list;
	}
	
	
	
	
	
	public class Node{
		protected T data;
		protected Node prev;
		protected Node next;
		public Node(T dataNode) {
			this.data=dataNode;
			this.prev=null;
			this.next=null;
		}
	}
	
	public class DoubleLinkedListIterator implements ListIterator<T> {
		protected Node currentNode;
		protected int numNodes;
		
		public DoubleLinkedListIterator() {
			this.currentNode=head;
			this.numNodes=1;
		
		}
		//TODO return true if the list has more elements going forward 
			
		public boolean hasNext() {
			return next()!= new NoSuchElementException();
			
		}
		//TODO returns the next elements in the list and advances cursor
		public T next( )throws NoSuchElementException{
			Node n= currentNode.next;
			if(n==null) {
				throw new NoSuchElementException();

			}else {
				currentNode=n;

				return n.data;
			}
			
		}
		
		//TODO returns true if there are more elements going backward
		public boolean hasPrevious() {
			return previous()!= new NoSuchElementException();
			
			
		}
		//TODO returns the previous elements in the list and moves the cursor backwards
		public T previous()throws NoSuchElementException{
			Node n=currentNode.prev;
			if(n==null) {
				throw new NoSuchElementException();
			}else {
				currentNode=n;
				return n.data;
			}
			
		}
		public void remove() throws UnsupportedOperationException {
			throw new UnsupportedOperationException();
		}
		public void add(T arg0) throws UnsupportedOperationException{
			throw new UnsupportedOperationException();
		}
		public int nextIndex()throws UnsupportedOperationException{
			throw new UnsupportedOperationException();
		}
		public int previousIndex()throws UnsupportedOperationException{
			throw new UnsupportedOperationException();
		}
		public void set(T arg0)throws UnsupportedOperationException{
			throw new UnsupportedOperationException();
		}
	
		
	}
	
	

}
