import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class GradeBookTest {
	private GradeBook b1,b2;

	@BeforeEach
	void setUp() throws Exception {
		b1= new GradeBook(5);
		b2=new GradeBook(5);
		b1.addScore(55);
		b1.addScore(89.5);
		b2.addScore(78.6);
		b2.addScore(95);
	}

	@AfterEach
	void tearDown() throws Exception {
		b1=b2=null;
	}

	@Test
	void testAddScore() {
		assertTrue(b1.addScore(55));
		b2.addScore(65.2);
		b2.addScore(96.0);
		b2.addScore(77.5);
		assertFalse(b2.addScore(100));


	}

	@Test
	void testSum() {
		assertEquals(144.5,b1.sum(),.01);
		assertEquals(173.6,b2.sum(),.01);
	}

	@Test
	void testMinimum() {
		assertEquals(55.0,b1.minimum(),.01);
		assertEquals(78.6,b2.minimum(),.01);
	}

	@Test
	void testFinalScore() {
		assertEquals(89.5,b1.finalScore(),.01);
		assertEquals(95.0,b2.finalScore(),.01);
	}

	@Test
	void testGetScoreSize() {
		assertEquals(2,b1.getScoreSize());
		b1.addScore(88);
		assertEquals(3,b1.getScoreSize());
		assertEquals(2,b2.getScoreSize());

	}

	@Test
	void testToString() {
		assertEquals("55.0 89.5 0.0 0.0 0.0 ",b1.toString());
		b2.addScore(45);
		assertEquals("78.6 95.0 45.0 0.0 0.0 ",b2.toString());
	}

}
